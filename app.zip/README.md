# Devsu Demo DevOps Project

Project setup with Docker, Kubernetes, and GitHub Actions.
